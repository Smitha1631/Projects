from plagiarism_checker.detector import PlagiarismDetector


def test_compare_returns_unique_pairs():
    detector = PlagiarismDetector(threshold=0.2)
    docs = {
        "a.txt": "The quick brown fox jumps over the lazy dog.",
        "b.txt": "The quick brown fox jumps over a lazy dog.",
        "c.txt": "Ocean temperatures influence marine ecosystems.",
    }
    results = detector.compare(docs)
    assert len(results) == 3
    assert results[0]["similarity"] >= results[-1]["similarity"]
    assert all("flagged" in row for row in results)

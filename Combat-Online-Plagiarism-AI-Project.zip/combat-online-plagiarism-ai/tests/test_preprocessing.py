from plagiarism_checker.preprocessing import normalize_text


def test_normalize_text_removes_punctuation_and_case():
    assert normalize_text("Hello, WORLD!") == "hello world"

"""Command-line entry point for the AI-assisted plagiarism checker."""
from __future__ import annotations

import argparse
from pathlib import Path

from plagiarism_checker.detector import PlagiarismDetector
from plagiarism_checker.reporting import save_report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Detect potentially duplicated text across a folder of .txt documents."
    )
    parser.add_argument(
        "input", nargs="?", default="sample_documents",
        help="Folder containing .txt files (default: sample_documents)",
    )
    parser.add_argument("--threshold", type=float, default=0.30,
                        help="Similarity threshold from 0 to 1 (default: 0.30)")
    parser.add_argument("--output", default="reports/plagiarism_report",
                        help="Output file path without extension")
    parser.add_argument("--top", type=int, default=20,
                        help="Maximum result pairs to display (default: 20)")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if not 0 <= args.threshold <= 1:
        raise SystemExit("--threshold must be between 0 and 1")

    detector = PlagiarismDetector(threshold=args.threshold)
    documents = detector.load_folder(args.input)
    if len(documents) < 2:
        raise SystemExit("Please provide at least two .txt documents in the input folder.")

    results = detector.compare(documents)
    output_files = save_report(results, args.output, args.threshold)

    flagged = [item for item in results if item["flagged"]]
    print(f"\nDocuments checked: {len(documents)}")
    print(f"Pairs compared: {len(results)}")
    print(f"Potentially suspicious pairs: {len(flagged)}")
    print(f"Threshold: {args.threshold:.0%}\n")

    for item in results[:max(args.top, 0)]:
        status = "FLAGGED" if item["flagged"] else "below threshold"
        print(
            f'{item["document_a"]}  <->  {item["document_b"]} | '
            f'{item["similarity"]:.1%} | fuzzy: {item["fuzzy_similarity"]:.1%} | {status}'
        )

    print("\nReports saved:")
    for path in output_files:
        print(f"  {path}")
    print("\nNote: similarity is a review signal, not proof of plagiarism.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

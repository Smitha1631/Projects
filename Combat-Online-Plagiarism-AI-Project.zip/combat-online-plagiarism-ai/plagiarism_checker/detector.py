"""TF-IDF, cosine similarity and fuzzy matching based detector."""
from __future__ import annotations

from itertools import combinations
from pathlib import Path
from typing import Mapping

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .preprocessing import normalize_text

try:
    from rapidfuzz import fuzz
except ImportError:  # graceful fallback if optional dependency is unavailable
    fuzz = None


class PlagiarismDetector:
    def __init__(self, threshold: float = 0.30) -> None:
        if not 0 <= threshold <= 1:
            raise ValueError("threshold must be between 0 and 1")
        self.threshold = threshold

    @staticmethod
    def load_folder(folder: str | Path) -> dict[str, str]:
        """Read UTF-8 text files from a folder (non-recursive)."""
        path = Path(folder)
        if not path.exists() or not path.is_dir():
            raise FileNotFoundError(f"Input folder does not exist: {path}")
        documents: dict[str, str] = {}
        for file_path in sorted(path.glob("*.txt")):
            try:
                content = file_path.read_text(encoding="utf-8-sig")
            except UnicodeDecodeError:
                content = file_path.read_text(encoding="latin-1")
            if content.strip():
                documents[file_path.name] = content
        return documents

    def compare(self, documents: Mapping[str, str]) -> list[dict]:
        """Compare every unique document pair and return sorted result records."""
        names = list(documents.keys())
        if len(names) < 2:
            return []

        raw_texts = [documents[name] for name in names]
        normalized = [normalize_text(text) for text in raw_texts]

        # Word n-grams catch reused wording; character n-grams help with
        # small spelling/spacing changes and lightly edited passages.
        word_vectorizer = TfidfVectorizer(
            ngram_range=(1, 2), sublinear_tf=True, max_features=50000,
            token_pattern=r"(?u)\b\w+\b"
        )
        char_vectorizer = TfidfVectorizer(
            analyzer="char_wb", ngram_range=(3, 5),
            sublinear_tf=True, max_features=50000
        )

        word_matrix = word_vectorizer.fit_transform(normalized)
        char_matrix = char_vectorizer.fit_transform(normalized)
        word_scores = cosine_similarity(word_matrix)
        char_scores = cosine_similarity(char_matrix)

        results = []
        for i, j in combinations(range(len(names)), 2):
            word_score = float(word_scores[i, j])
            char_score = float(char_scores[i, j])
            # Word features receive more weight; character features provide
            # robustness to minor edits and formatting variations.
            combined = (0.75 * word_score) + (0.25 * char_score)
            fuzzy_score = self._fuzzy_score(raw_texts[i], raw_texts[j])
            # Fuzzy matching is reported separately to avoid allowing a short
            # matching fragment to dominate the full-document score.
            results.append({
                "document_a": names[i],
                "document_b": names[j],
                "similarity": round(combined, 6),
                "word_similarity": round(word_score, 6),
                "character_similarity": round(char_score, 6),
                "fuzzy_similarity": round(fuzzy_score, 6),
                "flagged": combined >= self.threshold,
            })

        return sorted(results, key=lambda row: row["similarity"], reverse=True)

    @staticmethod
    def _fuzzy_score(text_a: str, text_b: str) -> float:
        if fuzz is None:
            return 0.0
        # token_set_ratio is tolerant of word order and repeated tokens.
        return float(fuzz.token_set_ratio(
            normalize_text(text_a), normalize_text(text_b)
        )) / 100.0

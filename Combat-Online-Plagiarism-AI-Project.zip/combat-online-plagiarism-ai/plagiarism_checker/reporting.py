"""CSV, JSON and standalone HTML report generation."""
from __future__ import annotations

import csv
import html
import json
from pathlib import Path
from typing import Iterable


FIELDS = [
    "document_a", "document_b", "similarity", "word_similarity",
    "character_similarity", "fuzzy_similarity", "flagged",
]


def save_report(results: Iterable[dict], output_base: str, threshold: float) -> list[str]:
    base = Path(output_base)
    base.parent.mkdir(parents=True, exist_ok=True)
    rows = list(results)
    paths = []

    csv_path = base.with_suffix(".csv")
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    paths.append(str(csv_path))

    json_path = base.with_suffix(".json")
    json_path.write_text(json.dumps({
        "threshold": threshold,
        "pairs_compared": len(rows),
        "flagged_pairs": sum(bool(row["flagged"]) for row in rows),
        "results": rows,
        "disclaimer": "Similarity scores are indicators for human review, not proof of plagiarism."
    }, indent=2), encoding="utf-8")
    paths.append(str(json_path))

    html_path = base.with_suffix(".html")
    body_rows = []
    for row in rows:
        status = "Flagged" if row["flagged"] else "Below threshold"
        body_rows.append(
            "<tr>" +
            f"<td>{html.escape(row['document_a'])}</td>" +
            f"<td>{html.escape(row['document_b'])}</td>" +
            f"<td>{row['similarity']:.1%}</td>" +
            f"<td>{row['word_similarity']:.1%}</td>" +
            f"<td>{row['character_similarity']:.1%}</td>" +
            f"<td>{row['fuzzy_similarity']:.1%}</td>" +
            f"<td>{status}</td></tr>"
        )
    html_doc = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Plagiarism Similarity Report</title>
<style>
body{{font:15px system-ui,sans-serif;margin:32px;color:#202124;background:#f7f8fa}}
main{{max-width:1100px;margin:auto;background:white;padding:28px;border-radius:12px}}
table{{border-collapse:collapse;width:100%;margin-top:20px}}th,td{{padding:10px;border-bottom:1px solid #ddd;text-align:left}}
th{{background:#eef1f5}}.note{{color:#555;margin-top:24px}}
</style></head><body><main>
<h1>Plagiarism Similarity Report</h1>
<p>Threshold: {threshold:.0%} · Pairs compared: {len(rows)} · Flagged: {sum(bool(r['flagged']) for r in rows)}</p>
<table><thead><tr><th>Document A</th><th>Document B</th><th>Combined</th><th>Word</th><th>Character</th><th>Fuzzy</th><th>Status</th></tr></thead>
<tbody>{''.join(body_rows)}</tbody></table>
<p class="note">A high similarity score is a screening signal only. Review the source passages, citations and context before making any conclusion.</p>
</main></body></html>"""
    html_path.write_text(html_doc, encoding="utf-8")
    paths.append(str(html_path))
    return paths

"""Text similarity and plagiarism screening package."""
__version__ = "1.0.0"

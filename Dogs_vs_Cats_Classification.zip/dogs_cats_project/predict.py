"""Predict: python predict.py path/to/image.jpg"""
import argparse
from pathlib import Path
import tensorflow as tf


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('image')
    parser.add_argument('--model', default='models/best_model.keras')
    args = parser.parse_args()
    if not Path(args.model).exists():
        raise SystemExit('Model missing: run train.py first.')
    model = tf.keras.models.load_model(args.model)
    height, width = model.input_shape[1:3]
    image = tf.keras.utils.load_img(args.image, target_size=(height, width))
    tensor = tf.expand_dims(tf.keras.utils.img_to_array(image), 0)
    p_dog = float(model.predict(tensor, verbose=0)[0][0])
    label = 'Dog' if p_dog >= 0.5 else 'Cat'
    confidence = p_dog if label == 'Dog' else 1 - p_dog
    print(f'{label}: {confidence:.2%} confidence')


if __name__ == '__main__':
    main()

"""Evaluate: python evaluate.py --data data"""
import argparse
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from sklearn.metrics import classification_report, ConfusionMatrixDisplay, confusion_matrix


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='data')
    parser.add_argument('--model', default='models/best_model.keras')
    parser.add_argument('--batch-size', type=int, default=32)
    args = parser.parse_args()
    if not Path(args.model).exists():
        raise SystemExit('Model missing: run train.py first.')
    model = tf.keras.models.load_model(args.model)
    height, width = model.input_shape[1:3]
    ds = tf.keras.utils.image_dataset_from_directory(
        Path(args.data) / 'test', label_mode='binary', class_names=['cats', 'dogs'],
        image_size=(height, width), batch_size=args.batch_size, shuffle=False)
    y_true = np.concatenate([labels.numpy().ravel() for _, labels in ds]).astype(int)
    y_pred = (model.predict(ds, verbose=0).ravel() >= 0.5).astype(int)
    Path('outputs').mkdir(exist_ok=True)
    report = classification_report(y_true, y_pred, target_names=['cats', 'dogs'], zero_division=0)
    print(report)
    Path('outputs/classification_report.txt').write_text(report)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    ConfusionMatrixDisplay(cm, display_labels=['cats', 'dogs']).plot(cmap='Blues')
    plt.tight_layout()
    plt.savefig('outputs/confusion_matrix.png', dpi=150)
    plt.close()


if __name__ == '__main__':
    main()

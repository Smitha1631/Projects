"""Train: python train.py --data data --epochs 10"""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import tensorflow as tf
from src.model import build_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='data')
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--image-size', type=int, default=180)
    args = parser.parse_args()
    root = Path(args.data)
    size = (args.image_size, args.image_size)
    datasets = {}
    for split in ('train', 'val'):
        folder = root / split
        if not folder.is_dir() or not any(folder.rglob('*.jpg')) and not any(folder.rglob('*.png')) and not any(folder.rglob('*.jpeg')):
            raise SystemExit(f'Add cat/dog images to {folder}/cats and {folder}/dogs first.')
        datasets[split] = tf.keras.utils.image_dataset_from_directory(
            folder, labels='inferred', label_mode='binary', class_names=['cats', 'dogs'],
            image_size=size, batch_size=args.batch_size, shuffle=(split == 'train'), seed=42)
    train_ds = datasets['train'].prefetch(tf.data.AUTOTUNE)
    val_ds = datasets['val'].prefetch(tf.data.AUTOTUNE)
    model = build_model(size)
    Path('models').mkdir(exist_ok=True)
    Path('outputs').mkdir(exist_ok=True)
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint('models/best_model.keras', save_best_only=True, monitor='val_loss'),
        tf.keras.callbacks.EarlyStopping(patience=4, restore_best_weights=True),
    ]
    history = model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=callbacks)
    model.save('models/final_model.keras')
    with open('outputs/history.json', 'w') as f:
        json.dump({k: [float(v) for v in values] for k, values in history.history.items()}, f, indent=2)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, metric in zip(axes, ('accuracy', 'loss')):
        ax.plot(history.history[metric], label='Train')
        ax.plot(history.history['val_' + metric], label='Validation')
        ax.set_title(metric.capitalize())
        ax.set_xlabel('Epoch')
        ax.legend()
    fig.tight_layout()
    fig.savefig('outputs/training_curves.png', dpi=150)
    plt.close(fig)
    print('Saved trained models and training curves.')


if __name__ == '__main__':
    main()

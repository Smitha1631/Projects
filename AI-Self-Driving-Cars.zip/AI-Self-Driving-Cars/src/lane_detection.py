import cv2
import numpy as np

def detect_lanes(frame):
    """Return annotated frame, normalized lateral error, and confidence."""
    h, w = frame.shape[:2]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 60, 150)
    mask = np.zeros_like(edges)
    polygon = np.array([[(0,h-1),(int(w*.43),int(h*.55)),(int(w*.57),int(h*.55)),(w-1,h-1)]],np.int32)
    cv2.fillPoly(mask, polygon, 255)
    edges = cv2.bitwise_and(edges, mask)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, 35, minLineLength=35, maxLineGap=70)
    left, right = [], []
    if lines is not None:
        for x1,y1,x2,y2 in lines[:,0]:
            if x2 == x1: continue
            slope = (y2-y1)/(x2-x1)
            if abs(slope) < .35 or abs(slope) > 6: continue
            intercept = y1-slope*x1
            (left if slope < 0 else right).append((slope,intercept))
    out=frame.copy(); xs=[]
    for group in (left,right):
        if not group: continue
        slope,intercept=np.median(group,axis=0)
        ybottom=h-1; ytop=int(h*.60)
        xbottom=int(np.clip((ybottom-intercept)/slope,0,w-1))
        xtop=int(np.clip((ytop-intercept)/slope,0,w-1))
        cv2.line(out,(xbottom,ybottom),(xtop,ytop),(0,255,0),5)
        xs.append(xbottom)
    confidence=len(xs)/2
    center=(xs[0]+xs[1])/2 if len(xs)==2 else (xs[0]+w*.25 if left else xs[0]-w*.25) if xs else w/2
    error=float(np.clip((center-w/2)/(w/2),-1,1))
    cv2.circle(out,(int(np.clip(center,0,w-1)),h-25),7,(0,0,255),-1)
    return out,error,confidence

import cv2
import numpy as np

def detect_obstacles(frame):
    """Detect red obstacles in the simulator; returns bounding boxes."""
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    low=cv2.inRange(hsv,np.array([0,100,90]),np.array([12,255,255]))
    high=cv2.inRange(hsv,np.array([170,100,90]),np.array([179,255,255]))
    mask=cv2.morphologyEx(low|high,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
    contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    return [cv2.boundingRect(c) for c in contours if cv2.contourArea(c)>250]

def assess_risk(boxes,width,height):
    for x,y,w,h in boxes:
        if x < width*.65 and x+w > width*.35 and y+h > height*.72:
            return True
    return False

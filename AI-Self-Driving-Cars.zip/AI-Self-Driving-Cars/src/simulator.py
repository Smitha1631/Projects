import cv2
import numpy as np

def synthetic_frame(t,width=960,height=540):
    """Draw an illustrative roadway, moving lane offsets, and occasional obstacle."""
    frame=np.full((height,width,3),(65,65,65),np.uint8)
    cv2.rectangle(frame,(0,0),(width,int(height*.55)),(185,145,95),-1)
    offset=int(65*np.sin(t*.35))
    left_bottom=int(width*.23)+offset
    right_bottom=int(width*.77)+offset
    left_top=int(width*.46)+offset
    right_top=int(width*.54)+offset
    cv2.line(frame,(left_bottom,height-1),(left_top,int(height*.55)),(255,255,255),9)
    cv2.line(frame,(right_bottom,height-1),(right_top,int(height*.55)),(255,255,255),9)
    if int(t)%12 in (7,8,9):
        y=int(height*(.68+.06*(t%1)))
        cv2.rectangle(frame,(width//2-40,y),(width//2+40,y+75),(0,0,220),-1)
    return frame

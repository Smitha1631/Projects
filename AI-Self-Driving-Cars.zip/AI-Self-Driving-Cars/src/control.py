class PIDController:
    def __init__(self,kp=.8,ki=.02,kd=.12,limit=1.0):
        self.kp,self.ki,self.kd,self.limit=kp,ki,kd,limit
        self.integral=0.0
        self.previous=0.0
    def update(self,error,dt):
        dt=max(float(dt),1e-3)
        self.integral=max(-2.0,min(2.0,self.integral+error*dt))
        derivative=(error-self.previous)/dt
        self.previous=error
        value=self.kp*error+self.ki*self.integral+self.kd*derivative
        return max(-self.limit,min(self.limit,value))

import unittest
from src.simulator import synthetic_frame
from src.lane_detection import detect_lanes
from src.perception import detect_obstacles,assess_risk
from src.control import PIDController

class PipelineTests(unittest.TestCase):
    def test_lanes(self):
        frame=synthetic_frame(0)
        annotated,error,confidence=detect_lanes(frame)
        self.assertEqual(annotated.shape,frame.shape)
        self.assertGreater(confidence,0)
        self.assertLess(abs(error),.4)
    def test_obstacles(self):
        frame=synthetic_frame(7.5)
        self.assertTrue(detect_obstacles(frame))
    def test_pid_limits(self):
        pid=PIDController()
        self.assertLessEqual(abs(pid.update(100,.1)),1)
    def test_risk(self):
        self.assertTrue(assess_risk([(450,420,80,80)],960,540))
        self.assertFalse(assess_risk([(0,0,20,20)],960,540))

if __name__=='__main__': unittest.main()

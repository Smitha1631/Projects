"""Educational ADAS demo; not suitable for real vehicle control."""
import argparse
import time
from pathlib import Path
import cv2
from src.lane_detection import detect_lanes
from src.perception import detect_obstacles,assess_risk
from src.control import PIDController
from src.simulator import synthetic_frame

def run(source='simulation',output=None,max_frames=300,display=True):
    cap=None if source=='simulation' else cv2.VideoCapture(int(source) if source.isdigit() else source)
    if cap is not None and not cap.isOpened(): raise ValueError(f'Cannot open video source: {source}')
    controller=PIDController(); writer=None; index=0; last=time.monotonic()
    try:
        while max_frames<=0 or index<max_frames:
            if cap is None: frame=synthetic_frame(index/20)
            else:
                ok,frame=cap.read()
                if not ok: break
            now=time.monotonic(); dt=max(now-last,.05) if cap is None else max(now-last,.001);last=now
            annotated,error,confidence=detect_lanes(frame)
            boxes=detect_obstacles(frame)
            danger=assess_risk(boxes,frame.shape[1],frame.shape[0])
            steering=controller.update(error,dt) if confidence else 0.0
            throttle=0.0 if danger else (0.25 if confidence else 0.0)
            for x,y,w,h in boxes: cv2.rectangle(annotated,(x,y),(x+w,y+h),(0,255,255),3)
            status=f'Steer: {steering:+.2f} | Throttle: {throttle:.2f} | Lane: {confidence:.1f}'
            cv2.putText(annotated,status,(18,35),cv2.FONT_HERSHEY_SIMPLEX,.7,(255,255,255),2)
            cv2.putText(annotated,'STOP: OBSTACLE' if danger else 'SIMULATION / ADAS DEMO',(18,70),cv2.FONT_HERSHEY_SIMPLEX,.75,(0,0,255) if danger else (255,255,255),2)
            if output:
                if writer is None:
                    Path(output).parent.mkdir(parents=True,exist_ok=True)
                    writer=cv2.VideoWriter(output,cv2.VideoWriter_fourcc(*'mp4v'),20,(frame.shape[1],frame.shape[0]))
                    if not writer.isOpened(): raise ValueError('Cannot create output video')
                writer.write(annotated)
            if display:
                cv2.imshow('AI Self-Driving Cars - Educational Demo',annotated)
                if cv2.waitKey(1)&0xFF==ord('q'): break
            index+=1
    finally:
        if cap is not None:cap.release()
        if writer is not None:writer.release()
        if display:cv2.destroyAllWindows()
    return index

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Lane detection + obstacle perception + PID simulation')
    parser.add_argument('--source',default='simulation',help='simulation, webcam index, or video path')
    parser.add_argument('--output',default=None,help='Optional output mp4')
    parser.add_argument('--frames',type=int,default=300,help='0 means until video ends or q pressed')
    parser.add_argument('--no-display',action='store_true')
    args=parser.parse_args()
    print('Frames processed:',run(args.source,args.output,args.frames,not args.no_display))

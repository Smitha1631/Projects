"""Reusable CountVectorizer + Multinomial Naive Bayes sentiment pipeline."""
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from src.preprocessing import preprocess_review

BEST_ALPHA = 0.2

def build_model(alpha: float = BEST_ALPHA) -> Pipeline:
    return Pipeline([
        ("vectorizer", CountVectorizer(
            preprocessor=preprocess_review,
            max_features=1500
        )),
        ("classifier", MultinomialNB(alpha=alpha)),
    ])

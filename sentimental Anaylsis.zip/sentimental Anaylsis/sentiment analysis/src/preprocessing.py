"""Text preprocessing matching the original notebook's approach."""
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

def ensure_nltk_stopwords():
    """Download NLTK stopwords on first use when they are not installed."""
    try:
        stopwords.words("english")
    except LookupError:
        nltk.download("stopwords", quiet=True)

ensure_nltk_stopwords()
STOP_WORDS = set(stopwords.words("english"))
STEMMER = PorterStemmer()

def preprocess_review(review: str) -> str:
    """Remove non-letters, lowercase, remove English stopwords, and stem."""
    review = "" if review is None else str(review)
    review = re.sub(r"[^a-zA-Z]", " ", review).lower()
    words = review.split()
    words = [word for word in words if word not in STOP_WORDS]
    return " ".join(STEMMER.stem(word) for word in words)

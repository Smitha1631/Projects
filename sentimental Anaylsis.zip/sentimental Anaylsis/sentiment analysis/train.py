"""Train and evaluate the restaurant review sentiment classifier."""
from pathlib import Path
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)
from src.model import build_model

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "Restaurant_Reviews.tsv"
MODEL_PATH = ROOT / "models" / "sentiment_model.joblib"

def load_data(path=DATA_PATH):
    data = pd.read_csv(path, delimiter="\\t")
    if not {"Review", "Liked"}.issubset(data.columns):
        raise ValueError("Dataset must contain 'Review' and 'Liked' columns.")
    data = data.dropna(subset=["Review", "Liked"]).copy()
    data["Liked"] = data["Liked"].astype(int)
    if not set(data["Liked"].unique()).issubset({0, 1}):
        raise ValueError("Liked labels must be 0 (Negative) or 1 (Positive).")
    if data["Liked"].nunique() != 2 or data["Liked"].value_counts().min() < 2:
        raise ValueError("Need at least two examples for each sentiment class.")
    return data

def main():
    data = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        data["Review"], data["Liked"],
        test_size=0.20, random_state=0, stratify=data["Liked"]
    )
    model = build_model()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)
    precision = precision_score(y_test, predictions, zero_division=0)
    recall = recall_score(y_test, predictions, zero_division=0)
    f1 = f1_score(y_test, predictions, zero_division=0)

    print("\\n--------- EVALUATION SCORES ---------")
    print(f"Accuracy : {accuracy * 100:.2f}%")
    print(f"Precision: {precision * 100:.2f}%")
    print(f"Recall   : {recall * 100:.2f}%")
    print(f"F1-score : {f1 * 100:.2f}%")
    print("\\nClassification report:")
    print(classification_report(
        y_test, predictions, target_names=["Negative", "Positive"], zero_division=0
    ))
    print("Confusion matrix (rows=actual, columns=predicted):")
    print(confusion_matrix(y_test, predictions, labels=[0, 1]))

    # Match the original notebook's selected alpha=0.2 for final training.
    final_model = build_model(alpha=0.2)
    final_model.fit(data["Review"], data["Liked"])
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(final_model, MODEL_PATH)
    print(f"\\nSaved model to: {MODEL_PATH}")

if __name__ == "__main__":
    main()

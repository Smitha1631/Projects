from src.preprocessing import preprocess_review

def test_lowercase_and_punctuation_removed():
    assert preprocess_review("GREAT food!!!") == "great food"

def test_stemming_applied():
    assert preprocess_review("The meals were delicious") == "meal delici"

def test_empty_input():
    assert preprocess_review("") == ""

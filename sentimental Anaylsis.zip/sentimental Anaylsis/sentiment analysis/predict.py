"""Predict whether a restaurant review is positive or negative."""
from pathlib import Path
import argparse
import joblib

MODEL_PATH = Path(__file__).resolve().parent / "models" / "sentiment_model.joblib"

def main():
    parser = argparse.ArgumentParser(description="Restaurant review sentiment prediction")
    parser.add_argument("review", help="Review text in quotation marks")
    args = parser.parse_args()
    if not MODEL_PATH.exists():
        raise SystemExit("Model not found. Run `python train.py` first.")
    model = joblib.load(MODEL_PATH)
    prediction = int(model.predict([args.review])[0])
    print("Positive review" if prediction == 1 else "Negative review")
    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba([args.review])[0]
        print(f"Negative: {probabilities[0]:.1%}")
        print(f"Positive: {probabilities[1]:.1%}")

if __name__ == "__main__":
    main()

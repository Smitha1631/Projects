"""Simple Streamlit app for restaurant review sentiment analysis."""
from pathlib import Path
import joblib
import streamlit as st

MODEL_PATH = Path(__file__).resolve().parent / "models" / "sentiment_model.joblib"

st.set_page_config(page_title="Restaurant Review Sentiment", page_icon="🍽️")
st.title("🍽️ Restaurant Review Sentiment Analysis")
st.write("Enter a restaurant review to classify it as positive or negative.")

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

model = load_model()
if model is None:
    st.warning("The model has not been trained yet. Run these commands in the project folder:")
    st.code("pip install -r requirements.txt\\npython train.py\\nstreamlit run app.py")
    st.stop()

review = st.text_area("Enter your review", placeholder="The food was delicious and the service was excellent.")
if st.button("Analyze review", type="primary"):
    if not review.strip():
        st.info("Please enter a review first.")
    else:
        result = int(model.predict([review])[0])
        if result == 1:
            st.success("😊 Positive review")
        else:
            st.error("☹️ Negative review")
        probabilities = model.predict_proba([review])[0]
        st.caption("Model probability estimates")
        st.write(f"Negative: {probabilities[0]:.1%}")
        st.progress(float(probabilities[0]))
        st.write(f"Positive: {probabilities[1]:.1%}")
        st.progress(float(probabilities[1]))

st.caption("Educational demo. The included sample dataset is small; train with a larger labelled dataset for reliable results.")

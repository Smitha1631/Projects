"""Train with train/validation/test splits; resampling happens only on training folds."""
import argparse
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.metrics import (average_precision_score, roc_auc_score, precision_score, recall_score, f1_score, confusion_matrix, PrecisionRecallDisplay, RocCurveDisplay)
from src.pipeline import FEATURES, TARGET, validate_frame, build_pipeline, find_best_threshold

def metrics(y, scores, threshold):
    labels = (scores >= threshold).astype(int)
    return {'pr_auc': float(average_precision_score(y, scores)), 'roc_auc': float(roc_auc_score(y, scores)), 'precision': float(precision_score(y, labels, zero_division=0)), 'recall': float(recall_score(y, labels, zero_division=0)), 'f1': float(f1_score(y, labels, zero_division=0)), 'confusion_matrix': confusion_matrix(y, labels, labels=[0,1]).tolist()}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data', default='creditcard.csv')
    p.add_argument('--model', choices=['logistic','random_forest','hist_gradient_boosting'], default='logistic')
    p.add_argument('--sampler', choices=['smote','none'], default='smote')
    p.add_argument('--cv', type=int, default=0, help='Optional stratified CV folds on training partition (>=2)')
    p.add_argument('--fp-cost', type=float, default=1.0)
    p.add_argument('--fn-cost', type=float, default=10.0)
    p.add_argument('--output', default='models/fraud_pipeline.joblib')
    p.add_argument('--report-dir', default='reports')
    args=p.parse_args()
    if args.cv == 1 or args.cv < 0 or args.fp_cost < 0 or args.fn_cost < 0:
        p.error('CV must be 0 or >=2 and costs must be nonnegative')
    df=pd.read_csv(args.data)
    X=validate_frame(df)
    y=df[TARGET].astype(int)
    if y.nunique()!=2 or y.value_counts().min()<3:
        raise ValueError('Need at least three samples of each class for stratified splits')
    X_trainval,X_test,y_trainval,y_test=train_test_split(X,y,test_size=0.2,stratify=y,random_state=42)
    X_train,X_val,y_train,y_val=train_test_split(X_trainval,y_trainval,test_size=0.25,stratify=y_trainval,random_state=42)
    pipe=build_pipeline(args.model,args.sampler)
    if args.cv:
        cv=StratifiedKFold(n_splits=args.cv,shuffle=True,random_state=42)
        cv_results=cross_validate(pipe,X_train,y_train,cv=cv,scoring={'pr_auc':'average_precision','roc_auc':'roc_auc'},n_jobs=1)
        print('Training-only CV:', {k:round(float(np.mean(v)),4) for k,v in cv_results.items() if k.startswith('test_')})
    pipe.fit(X_train,y_train)
    val_scores=pipe.predict_proba(X_val)[:,1]
    threshold=find_best_threshold(y_val.to_numpy(),val_scores,args.fp_cost,args.fn_cost)
    test_scores=pipe.predict_proba(X_test)[:,1]
    result={'model':args.model,'sampler':args.sampler,'threshold':threshold,'false_positive_cost':args.fp_cost,'false_negative_cost':args.fn_cost,'validation':metrics(y_val,val_scores,threshold),'test':metrics(y_test,test_scores,threshold),'train_rows':len(X_train),'validation_rows':len(X_val),'test_rows':len(X_test)}
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    report=Path(args.report_dir);report.mkdir(parents=True,exist_ok=True)
    joblib.dump({'pipeline':pipe,'threshold':threshold,'features':FEATURES},out)
    (report/'metrics.json').write_text(json.dumps(result,indent=2))
    fig,axes=plt.subplots(1,2,figsize=(12,5))
    PrecisionRecallDisplay.from_predictions(y_test,test_scores,ax=axes[0])
    RocCurveDisplay.from_predictions(y_test,test_scores,ax=axes[1])
    fig.tight_layout();fig.savefig(report/'evaluation.png',dpi=140);plt.close(fig)
    print(json.dumps(result,indent=2))
    print(f'Saved model to {out} and reports to {report}')
if __name__=='__main__':main()

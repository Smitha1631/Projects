"""Reusable training and scoring utilities for credit-card fraud detection."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.over_sampling import SMOTE

FEATURES = ['Time'] + [f'V{i}' for i in range(1, 29)] + ['Amount']
TARGET = 'Class'

def validate_frame(df, require_target=True):
    required = FEATURES + ([TARGET] if require_target else [])
    missing = sorted(set(required) - set(df.columns))
    if missing:
        raise ValueError(f'Missing required columns: {missing}')
    if df[required].isna().any().any():
        raise ValueError('Dataset contains missing feature/target values')
    if require_target and not set(df[TARGET].unique()).issubset({0, 1}):
        raise ValueError('Class must contain only 0 and 1')
    return df[FEATURES].copy()

def build_pipeline(model='logistic', sampler='smote', random_state=42):
    if model == 'logistic':
        estimator = LogisticRegression(max_iter=2000, class_weight='balanced' if sampler == 'none' else None, random_state=random_state)
    elif model == 'random_forest':
        estimator = RandomForestClassifier(n_estimators=150, min_samples_leaf=2, n_jobs=-1, class_weight='balanced_subsample' if sampler == 'none' else None, random_state=random_state)
    elif model == 'hist_gradient_boosting':
        estimator = HistGradientBoostingClassifier(max_iter=120, random_state=random_state)
    else:
        raise ValueError(f'Unsupported model: {model}')
    steps = [('scale', ColumnTransformer([('scale_amount_time', StandardScaler(), ['Time','Amount'])], remainder='passthrough'))]
    if sampler == 'smote':
        steps.append(('resample', SMOTE(random_state=random_state)))
    elif sampler != 'none':
        raise ValueError(f'Unsupported sampler: {sampler}')
    steps.append(('model', estimator))
    return ImbPipeline(steps)

def find_best_threshold(y_true, probabilities, false_positive_cost=1.0, false_negative_cost=10.0):
    thresholds = np.linspace(0.01, 0.99, 99)
    costs = [false_positive_cost * np.sum((probabilities >= t) & (y_true == 0)) + false_negative_cost * np.sum((probabilities < t) & (y_true == 1)) for t in thresholds]
    return float(thresholds[int(np.argmin(costs))])

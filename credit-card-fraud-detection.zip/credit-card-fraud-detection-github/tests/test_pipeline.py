import numpy as np
import pandas as pd
import pytest
from src.pipeline import FEATURES, validate_frame, build_pipeline, find_best_threshold

def test_validate():
    frame=pd.DataFrame(np.zeros((3,len(FEATURES))),columns=FEATURES)
    frame['Class']=[0,1,0]
    assert list(validate_frame(frame).columns)==FEATURES
    with pytest.raises(ValueError): validate_frame(frame.drop(columns=['V1']))

def test_threshold():
    y=np.array([0,0,1,1]); scores=np.array([0.1,0.2,0.8,0.9])
    assert 0.2 < find_best_threshold(y,scores) <= 0.8

def test_pipeline():
    rng=np.random.default_rng(42)
    X=pd.DataFrame(rng.normal(size=(80,len(FEATURES))),columns=FEATURES)
    y=np.array([0]*65+[1]*15)
    pipe=build_pipeline('logistic','smote')
    pipe.fit(X,y)
    assert pipe.predict_proba(X[:4]).shape==(4,2)

"""Score one or many transactions from a CSV with the standard feature columns."""
import argparse
from pathlib import Path
import joblib
import pandas as pd
from src.pipeline import validate_frame

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',default='models/fraud_pipeline.joblib')
    p.add_argument('--input',required=True)
    p.add_argument('--output',default='predictions.csv')
    args=p.parse_args()
    artifact=joblib.load(args.model)  # Load only models you created or trust.
    df=pd.read_csv(args.input)
    X=validate_frame(df,require_target=False)
    scores=artifact['pipeline'].predict_proba(X)[:,1]
    df['fraud_probability']=scores
    df['fraud_prediction']=(scores>=artifact['threshold']).astype(int)
    Path(args.output).parent.mkdir(parents=True,exist_ok=True)
    df.to_csv(args.output,index=False)
    print(f'Scored {len(df)} transactions -> {args.output}')
if __name__=='__main__':main()
